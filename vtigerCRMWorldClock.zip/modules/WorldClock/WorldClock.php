<?php
class WorldClock {}