<?php

$languageStrings = array(
    'World Clock' => 'Reloj mundial'
);