<?php

$languageStrings = array(
    'World Clock' => 'World Clock'
);